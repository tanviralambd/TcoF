package tcof.com.cbrc.parsing;

import java.util.LinkedHashMap;
import java.util.Vector;

import tcof.com.cbrc.common.CommonFunction;
import tcof.com.cbrc.constant.ConstantValue;

public class LoadAllTcoF {

	
	String fnameTcoF;
	
	LinkedHashMap<String, String> lhm_ACC_Name = new LinkedHashMap<String, String>();
	LinkedHashMap<String, String> lhmHighConfidence_ACC_Name = new LinkedHashMap<String, String>();
	
	
	
	
	LinkedHashMap<String, String> doProcessing( String fnmeTcoF)
	{
		this.fnameTcoF = fnmeTcoF;
		
		int skipTopLines = 10;
		
		String tmp[];
		String tcofACC, tcofName;
		int tcofClass;
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(fnmeTcoF);
		
		System.out.println("Total entry in TcoF file:" + ( vectAll.size() - skipTopLines )  ); 
		
		for(int i= skipTopLines; i<vectAll.size();i++)
		{
			
			tmp = ConstantValue.patWhiteSpace.split(vectAll.get(i));
			
			tcofACC   = tmp[0];
			tcofName  = tmp[1];
			tcofClass = Integer.parseInt( tmp[2] );
			
			if(lhm_ACC_Name.containsKey(tcofACC))
			{
				System.out.println(" Already exist tcof accno:" + tcofACC ); 
			}else
			{
				lhm_ACC_Name.put(tcofACC, tcofName);
			}
			
		}
		
		System.out.println("Total uniqye entry in TcoF file:" +  lhm_ACC_Name.size()  ); 
		
		return lhm_ACC_Name;
	}
	
	
	
	LinkedHashMap<String, String> doProcessingHighConfidence( String fnmeTcoF)
	{
		this.fnameTcoF = fnmeTcoF;
		
		int skipTopLines = 10;
		
		String tmp[];
		String tcofACC, tcofName;
		int tcofClass;
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(fnmeTcoF);
		
		System.out.println("Total entry in TcoF file:" + ( vectAll.size() - skipTopLines )  ); 
		
		for(int i= skipTopLines; i<vectAll.size();i++)
		{
			
			tmp = ConstantValue.patWhiteSpace.split(vectAll.get(i));
			
			tcofACC   = tmp[0];
			tcofName  = tmp[1];
			tcofClass = Integer.parseInt( tmp[2] );
			
			if(tcofClass ==1) // High Confidence Tcof
			{
				
				
				if(lhmHighConfidence_ACC_Name.containsKey(tcofACC))
				{
					System.out.println(" Already exist tcof accno:" + tcofACC ); 
				}else
				{
					lhmHighConfidence_ACC_Name.put(tcofACC, tcofName);
				}
				
			}
			
			
			
		}
		
		System.out.println("Total HIGH CONFIDENCE uniqye entry in TcoF file:" +  lhmHighConfidence_ACC_Name.size()  ); 
		
		return lhmHighConfidence_ACC_Name;
	}
	
	public static void main(String[] args) {
		
		LoadAllTcoF obj = new LoadAllTcoF();
		
		obj.doProcessing( args[0]);
//		obj.doProcessing("tcof_tcofs_20100927.txt");
		
	}
}
