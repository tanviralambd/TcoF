package tcof.com.cbrc.parsing;




import tcof.com.cbrc.common.*;
import tcof.com.cbrc.constant.ConstantValue;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

/*
 *  Replace the ALL motif names file with Subset of Motif Name;
 */
public class Merge_TFTcoF_ForGroupOfGene {

	
	String finSubsetGeneName;
	String finResult_Gene_TFTcoF;
	
	String fout;
	
	/*
	 *  Data Structure
	 */
	
	LinkedHashMap<String, String> lhm_geneName_geneName = new LinkedHashMap<String, String>();
	
	Vector<String> vect_Gene_TFTcoF_List = new Vector<String>();
	
	
	
	void init(String subsetMotif, String list_Gen_Motif, String out)
	{
		this.finSubsetGeneName = subsetMotif;
		this.finResult_Gene_TFTcoF = list_Gen_Motif;
		this.fout = out;
	}
	
	void load_Gene_Subset()
	{
		String curLine;
		String tmp[];
		int ind;
		Vector<String> vectSubsetMotif = CommonFunction.readlinesOfAfile(this.finSubsetGeneName);
		for(int i=0;i<vectSubsetMotif.size();i++)
		{
			curLine = vectSubsetMotif.get(i);
			

			lhm_geneName_geneName.put(curLine, curLine);
		}
		
	}
	
	
	void load_Gene_TFTcoF_List()
	{
		vect_Gene_TFTcoF_List = CommonFunction.readlinesOfAfile(this.finResult_Gene_TFTcoF);
	}
	
	void keepOnlySubsetGene()
	{
		String curLine, curTF;
		String tmp[],tmp2tfbsName[];
		String geneName;
		String prefix=null;
		int ind;
		
		StringBuffer bufGeneNames = new StringBuffer();
		StringBuffer bufResult = new StringBuffer();
		Set<String> setTfTcoF = new LinkedHashSet<String>();
		
		for(int i=0; i<vect_Gene_TFTcoF_List.size();i++)
		{
			curLine =  vect_Gene_TFTcoF_List.get(i);
			tmp= ConstantValue.patWhiteSpace.split(curLine);
			geneName = tmp[0];
			
			bufGeneNames.append(geneName+",");
			if(lhm_geneName_geneName.containsKey(geneName))
			{
				
				tmp2tfbsName= ConstantValue.patSemiColon_Comma.split(tmp[1]);
				
				for(int j=0;  j<tmp2tfbsName.length;j++)
				{
					curTF = tmp2tfbsName[j];
					setTfTcoF.add(curTF);
					
				}
				
			}
		}
		
		String allGenes = bufGeneNames.substring(0,bufGeneNames.length()-1) ;

		Iterator itr = setTfTcoF.iterator();
		while( itr.hasNext())
		{
			bufResult.append(  itr.next() +",");
		}
		
		String finalres =  allGenes + "\t" + bufResult.substring(0, bufResult.length()-1)+""; // removing comma
		
		CommonFunction.writeContentToFile(this.fout, finalres);
		
	}
	
	void doProcessing()
	{
		load_Gene_Subset();
		load_Gene_TFTcoF_List();
		keepOnlySubsetGene();
	}
	
	public static void main(String[] args) {
	
		
		Merge_TFTcoF_ForGroupOfGene obj = new Merge_TFTcoF_ForGroupOfGene();
//		obj.init("g1_genenames.txt","selectedPrimary.prom.bed.fa.map.selected.dnase.bed.gene.tf.tcof", 
//				"g1.gene.tf.tcof");
//		
		
		obj.init(args[0], args[1], args[2]);
		obj.doProcessing();
	
	}
	
	
}

