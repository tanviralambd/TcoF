package tcof.com.cbrc.parsing;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.Iterator;

import tcof.com.cbrc.common.CommonFunction;
import tcof.com.cbrc.constant.ConstantValue;

public class GenerateList_TF_TcoF_NAME {

	
	/*
	 *  Input
	 */
	String fnm_TFacc_TcoFacc;
	String fnm_TF_acc_name;
	String fnm_TcoF_acc_name;
	
	/*
	 *  Output
	 */
	String fnmOut;
	
	
	
	/*
	 *  Data Structure
	 */
	
	// KEY-UNIPROTacc  , VAL-UNIPROTname
	LinkedHashMap< String, Set<String>> lhm_TF_TcoF_acc = new LinkedHashMap<String, Set<String>>();
	
	LinkedHashMap< String, String> lhm_TF_acc_name = new LinkedHashMap<String, String>();
	LinkedHashMap< String, String> lhm_TcoF_acc_name = new LinkedHashMap<String, String>();
	
	

	
	void load_TF_Accession_Name()
	{
		Vector<String> vectAcc_Name = CommonFunction.readlinesOfAfile(this.fnm_TF_acc_name);
		String tmp[];
		
		for(int i=0;i<vectAcc_Name.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectAcc_Name.get(i));
			lhm_TF_acc_name.put(tmp[0], tmp[1]);
		}
		System.out.println("Total TF:" + lhm_TF_acc_name.size());
		
	}
	
	void load_TcoF_Accession_Name()
	{
		Vector<String> vectAcc_Name = CommonFunction.readlinesOfAfile(this.fnm_TcoF_acc_name);
		String tmp[];
		
		for(int i=0;i<vectAcc_Name.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectAcc_Name.get(i));
			lhm_TcoF_acc_name.put(tmp[0], tmp[1]);
		}
		System.out.println("Total TcoF:" + lhm_TcoF_acc_name.size());
	}
	
	void load_TF_TcoF_Accession()
	{
		Vector<String> vectAcc_Name = CommonFunction.readlinesOfAfile(this.fnm_TFacc_TcoFacc);
		String tmp[];
		String acc,name;
		
		for(int i=0;i<vectAcc_Name.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectAcc_Name.get(i));
			acc = tmp[0];
			name = tmp[1];
			
			if(lhm_TF_TcoF_acc.containsKey(acc))
			{
				lhm_TF_TcoF_acc.get(acc).add(name);
			}else
			{
				Set<String> v = new LinkedHashSet<String>();
				v.add(name);
				lhm_TF_TcoF_acc.put(acc, v);
			}
			
		}
	}
	
	
	void generateList_TFname1_TcoFnamesN()
	{
		StringBuffer bufResult = new StringBuffer();
		
		Set mykeys = lhm_TF_TcoF_acc.entrySet();
		Iterator itr = mykeys.iterator();
		while(itr.hasNext())
		{
			Map.Entry me = (Map.Entry) itr.next();
            String curKey = (String)me.getKey();
            Set<String> curVal = (Set<String>) me.getValue();
            
            // TF
			String curNameTF = lhm_TF_acc_name.get(curKey);
			bufResult.append(curNameTF+"\t");
			
			// TcoF
			Iterator itrSet = curVal.iterator();
			while( itrSet.hasNext())
			{
				
				bufResult.append(  lhm_TcoF_acc_name.get( itrSet.next() ) +";");
				
			}
			
//			for(int c=1;c<curVal.size();c++)
//			{
//				bufResult.append(  lhm_TcoF_acc_name.get( curVal.get(c) ) +";");
//			}
			
			bufResult.append("\n");
			
		}
		
		CommonFunction.writeContentToFile(this.fnmOut, bufResult+"");
	}
	
	
	void init(String acc, String TF_acc_name, String TcoF_acc_name, String outName)
	{
		this.fnm_TFacc_TcoFacc = acc;
		this.fnm_TF_acc_name = TF_acc_name;
		this.fnm_TcoF_acc_name = TcoF_acc_name;
		
		/*
		 *  Output
		 */
		this.fnmOut = outName;
	}
	
	
	void doProcessing()
	{
		load_TF_Accession_Name();
		load_TcoF_Accession_Name();
		
		load_TF_TcoF_Accession();
		generateList_TFname1_TcoFnamesN();
	}
	
	
	public static void main(String[] args) {
		GenerateList_TF_TcoF_NAME obj = new GenerateList_TF_TcoF_NAME();
		
		
//		obj.init("TF_Tcof.ACC.txt","TF.unique.ACC.name.txt" , "TcoF.unique.ACC.name.txt" , "TF_Tcof.Name.txt");
		
		obj.init(args[0],args[1],args[2],args[3]);
		
		obj.doProcessing();
	}
	
}
