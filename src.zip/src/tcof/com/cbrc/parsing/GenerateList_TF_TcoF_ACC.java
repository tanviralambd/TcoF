package tcof.com.cbrc.parsing;

import java.util.LinkedHashMap;
import java.util.Vector;

import tcof.com.cbrc.common.CommonFunction;
import tcof.com.cbrc.constant.ConstantValue;

public class GenerateList_TF_TcoF_ACC {

	
	String fnmInteraction;
	String fnmTcoF;
	String fnmOut;
	String extHighConfidence;
	
	
	LinkedHashMap<String, String> lhmTcoF_ACC_Name = new LinkedHashMap<String, String>();
	LinkedHashMap<String, String> lhmHighConfidence_ACC_Name = new LinkedHashMap<String, String>();
	
	
	void loadAllTcoF()
	{
		LoadAllTcoF ob = new LoadAllTcoF();
		lhmTcoF_ACC_Name = ob.doProcessing(this.fnmTcoF);
		lhmHighConfidence_ACC_Name = ob.doProcessingHighConfidence(this.fnmTcoF);
	}
	
	
	void doParsing()
	{
		
		Vector<String> vectPPI = CommonFunction.readlinesOfAfile(this.fnmInteraction);
		int skipHeaderLines=19;
		
		String tmp[]={""};
		String curLine="";
		String ACC_a,ACC_b;
		String bool_TF_a,bool_TF_b;
		
		StringBuffer bufListACC = new StringBuffer();
		StringBuffer bufListACChighconf = new StringBuffer();
		
		
		int totalSplit=0;
		
		try {
		
		for(int i=skipHeaderLines; i< vectPPI.size() ;i++) // 
		{
			curLine =  vectPPI.get(i).trim();
			if(curLine.length()>0)
			{
				
				
				tmp = ConstantValue.patTab.split( curLine); // 
				totalSplit = tmp.length;
				ACC_a = tmp[0]; ACC_b = tmp[1];
				
				bool_TF_a=tmp[totalSplit-2] ; bool_TF_b = tmp[totalSplit-1];
				
				if( bool_TF_a.equals("yes") && bool_TF_b.equals( "no") )
				{
					if(lhmTcoF_ACC_Name.containsKey(ACC_b)){
						bufListACC.append(ACC_a + "\t" + ACC_b  + "\n");
					}
					
					if(lhmHighConfidence_ACC_Name.containsKey(ACC_b)){
						bufListACChighconf.append(ACC_a + "\t" + ACC_b  + "\n");
					}
					
					
					
				}else if( bool_TF_a.equals("no") && bool_TF_b.equals( "yes") )
				{
					if(lhmTcoF_ACC_Name.containsKey(ACC_a)){
						bufListACC.append(ACC_b + "\t" + ACC_a  + "\n"  );
					}
					
					if(lhmHighConfidence_ACC_Name.containsKey(ACC_a)){
						bufListACChighconf.append(ACC_b + "\t" + ACC_a  + "\n");
					}
					
				}
				
				
				
				
				else if( bool_TF_a.equals("yes") && bool_TF_b.equals( "yes") )
				{
					
				}else if( bool_TF_a.equals("no") && bool_TF_b.equals( "no") )
				{
					// NOTHING IN FILE
				}
				
				
//				System.out.println(bufListACC +"");
				
				
			}
			
			
			
		}
		
		CommonFunction.writeContentToFile(this.fnmOut, bufListACC+"");
		CommonFunction.writeContentToFile(this.fnmOut+ this.extHighConfidence, bufListACChighconf+"");
		
		
		
		
		
		} catch (Exception e) {
			System.out.println("Total split: "+totalSplit);
			System.out.println("Error for: "+curLine);
			System.out.println("Error for: "+ tmp[0]);
			e.printStackTrace();
			
		}
		
	}
	
	
	
	void doProcessing()
	{
		loadAllTcoF();
		
		doParsing();
	}
	
	void init(String fnmInter, String fnmTcoF , String fout , String extensionHighConf)
	{
		this.fnmInteraction = fnmInter;
		this.fnmTcoF = fnmTcoF;
		this.fnmOut = fout;
		
		this.extHighConfidence = extensionHighConf;
		
	}
	
	public static void main(String[] args) {
		
		GenerateList_TF_TcoF_ACC obj = new GenerateList_TF_TcoF_ACC();
		obj.init(args[0], args[1] , args[2] , args[3]);
		
//		obj.init("tcof_ppi_20100927.txt", "tcof_tcofs_20100927.txt" , "TF_Tcof.ACC.txt"  , ".highconf");
//		obj.init("test.txt" , "tcof_tcofs_20100927.txt" , "TF_Tcof.ACC.txt" , ".highconf");
		obj.doProcessing();
		
	}
	
}
