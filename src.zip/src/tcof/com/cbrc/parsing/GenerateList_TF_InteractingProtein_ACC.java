package tcof.com.cbrc.parsing;



import java.util.Vector;

import tcof.com.cbrc.common.CommonFunction;
import tcof.com.cbrc.constant.ConstantValue;

public class GenerateList_TF_InteractingProtein_ACC {

	
	String fnmInteraction;
	String fnmOut;
	
	
	
	
	
	void doParsing()
	{
		
		Vector<String> vectPPI = CommonFunction.readlinesOfAfile(this.fnmInteraction);
		int skipHeaderLines=19;
		
		String tmp[]={""};
		String curLine="";
		String ACC_a,ACC_b;
		String bool_TF_a,bool_TF_b;
		
		StringBuffer bufListACC = new StringBuffer();
		int totalSplit=0;
		
		try {
		
		for(int i=skipHeaderLines; i< vectPPI.size() ;i++) // 
		{
			curLine =  vectPPI.get(i).trim();
			if(curLine.length()>0)
			{
				
				
				tmp = ConstantValue.patTab.split( curLine); // 
				totalSplit = tmp.length;
				ACC_a = tmp[0]; ACC_b = tmp[1];
				
				bool_TF_a=tmp[totalSplit-2] ; bool_TF_b = tmp[totalSplit-1];
				
				if( bool_TF_a.equals("yes") && bool_TF_b.equals( "no") )
				{
					bufListACC.append(ACC_a + "\t" + ACC_b  + "\n");
					
				}else if( bool_TF_a.equals("no") && bool_TF_b.equals( "yes") )
				{
					bufListACC.append(ACC_b + "\t" + ACC_a  + "\n"  );
				}else if( bool_TF_a.equals("yes") && bool_TF_b.equals( "yes") )
				{
					
				}else if( bool_TF_a.equals("no") && bool_TF_b.equals( "no") )
				{
					// NOTHING IN FILE
				}
				
				
//				System.out.println(bufListACC +"");
				
				
			}
			
			
			
		}
		
		CommonFunction.writeContentToFile(this.fnmOut, bufListACC+"");
		
		
		} catch (Exception e) {
			System.out.println("Total split: "+totalSplit);
			System.out.println("Error for: "+curLine);
			System.out.println("Error for: "+ tmp[0]);
			e.printStackTrace();
			
		}
		
	}
	
	
	
	
	void doProcessing()
	{
		doParsing();
	}
	
	void init(String fnmInter, String fout)
	{
		this.fnmInteraction = fnmInter;
		this.fnmOut = fout;
		
	}
	
	public static void main(String[] args) {
		
		GenerateList_TF_InteractingProtein_ACC obj = new GenerateList_TF_InteractingProtein_ACC();
//		obj.init(args[0], args[1]);
		
//		obj.init("tcof_ppi_20100927.txt", "TF_InteractProtein.ACC.txt" );
//		obj.init("test.txt", "TF_Tcof.ACC.txt" );
		obj.doProcessing();
		
	}
	
}
