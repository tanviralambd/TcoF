package tcof.com.cbrc.bean;

public class Promoter {
	String chrom;
    int start;
    int end;
    char strand;
    
    String desc;
    
    
	public Promoter(String chm,int st, int en,char stra , String desc) {

		this.chrom = chm;
		this.start = st;
		this.end = en;
		this.strand = stra;
        this.desc = desc;
    }
    
    
    public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}


	public String getChrom() {
		return chrom;
	}
	public void setChrom(String chrom) {
		this.chrom = chrom;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	public char getStrand() {
		return strand;
	}
	public void setStrand(char strand) {
		this.strand = strand;
	}
	

}

