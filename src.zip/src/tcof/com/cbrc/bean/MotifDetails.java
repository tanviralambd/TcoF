package tcof.com.cbrc.bean;

import java.util.LinkedHashMap;
import java.util.Vector;
import java.util.regex.Pattern;

public class MotifDetails {

	Pattern patTab = Pattern.compile("[\\s]+");
	
	int motifID;
	int motiflen;	
	LinkedHashMap<Integer, Vector<Integer>> lhmGenemap = new LinkedHashMap<Integer, Vector<Integer>>();
	
	
	public MotifDetails(int motifID , int motiflen)
	{
		this.motifID = motifID;
		this.motiflen = motiflen;		
	}
	
	public void addMapStartPos( int geneNo, String allPos)
	{
		String afterTrim = allPos.trim();
		if(afterTrim.length()>0)
		{
			String tmp[] = patTab.split(allPos);
			Vector<Integer> vectStart = new Vector<Integer>();
			for(int i=0; i<tmp.length ; i++)
			{
				vectStart.add( Integer.parseInt( tmp[i].substring(1))  );
			}
			lhmGenemap.put(geneNo, vectStart);
		}else
		{
			lhmGenemap.put(geneNo, null);
		}
		
		
	}

	public int getMotifID() {
		return motifID;
	}

	public void setMotifID(int motifID) {
		this.motifID = motifID;
	}

	public int getMotiflen() {
		return motiflen;
	}

	public void setMotiflen(int motiflen) {
		this.motiflen = motiflen;
	}

	public LinkedHashMap<Integer, Vector<Integer>> getLhmGenemap() {
		return lhmGenemap;
	}

	public void setLhmGenemap(LinkedHashMap<Integer, Vector<Integer>> lhmGenemap) {
		this.lhmGenemap = lhmGenemap;
	}
	
	
	
	
}
