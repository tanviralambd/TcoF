package tcof.com.cbrc.bean;

public class Dnase {

	
//	String chrom;
//    int start;
//    int end;
//    String name;
//    String score;
//    char strand;
//    
//    float signal;
//
//	public Dnase(String chrom, int start, int end, String name, String score,
//			char strand, float signal) {
//		super();
//		this.chrom = chrom;
//		this.start = start;
//		this.end = end;
//		this.name = name;
//		this.score = score;
//		this.strand = strand;
//		this.signal = signal;
//	}
//
//	public String getChrom() {
//		return chrom;
//	}
//
//	public void setChrom(String chrom) {
//		this.chrom = chrom;
//	}
//
//	public int getStart() {
//		return start;
//	}
//
//	public void setStart(int start) {
//		this.start = start;
//	}
//
//	public int getEnd() {
//		return end;
//	}
//
//	public void setEnd(int end) {
//		this.end = end;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getScore() {
//		return score;
//	}
//
//	public void setScore(String score) {
//		this.score = score;
//	}
//
//	public char getStrand() {
//		return strand;
//	}
//
//	public void setStrand(char strand) {
//		this.strand = strand;
//	}
//
//	public float getSignal() {
//		return signal;
//	}
//
//	public void setSignal(float signal) {
//		this.signal = signal;
//	}
    
    
    
    
	
}
