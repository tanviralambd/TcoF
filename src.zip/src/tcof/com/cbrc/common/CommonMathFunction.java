package tcof.com.cbrc.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;



public class CommonMathFunction {


	class ValForSort implements Comparable<ValForSort>{


		double valCurrent;


		public ValForSort(Double val) {
			super();
			this.valCurrent = val;
		}


		public int compareTo(ValForSort obj) {

			return (this.valCurrent > obj.valCurrent ) ? 1  :  -1 ;
		}


		public double getValCurrent() {
			return valCurrent;
		}


		public void setValCurrent(double valCurrent) {
			this.valCurrent = valCurrent;
		}


		

	} 

	public Double getTheMedian_NoAverage(Vector<Double> vectInp)
	{

//		Double tmp[] = { 6.7 , 2.3 , 8.9, 11.1 , 91.5 };

		double finalValue=0.0;
		int listSize;

		List myArrayList = new ArrayList();
		for(int c=0; c<vectInp.size();c++)
		{
			myArrayList.add( new ValForSort( vectInp.get(c) ) );
		}

		Collections.sort( myArrayList  );

		listSize=myArrayList.size();

		if(listSize==1)
		{
			finalValue = ( (ValForSort)myArrayList.get(0) ).getValCurrent() ;

		}else if(listSize%2 ==0) // even - select the big one
		{
			finalValue =  ( (ValForSort)myArrayList.get(listSize/2) ).getValCurrent() ;
		}else // odd - take the middle one
		{
			finalValue =  ( (ValForSort)myArrayList.get(listSize/2) ).getValCurrent() ;
		}

		
//		System.out.println( "Median:" + "\t"+ finalValue);
		
		return finalValue;
		
	}

	
	
	
	


}
