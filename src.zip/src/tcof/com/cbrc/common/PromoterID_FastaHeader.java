package tcof.com.cbrc.common;

import java.util.Vector;

import tcof.com.cbrc.constant.ConstantValue;

public class PromoterID_FastaHeader {

	String finPromoterBed;
	String finFasta;
	
	String fout;
	
	void init(String finProm, String finFas, String fo)
	{
		this.finPromoterBed = finProm;
		this.finFasta = finFas;
		
		this.fout = fo;
				
	}
	
	
	void doProcessing()
	{
		Vector<String> vectBed = CommonFunction.readlinesOfAfile(this.finPromoterBed);
		Vector<String> vectFastaHead =  CommonFunction.fasta_readFastaHeader(this.finFasta);
		
		String tmp[];
		StringBuffer bufResult = new StringBuffer();
		
		for(int i=0; i<vectBed.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectBed.get(i));
			
			bufResult.append(tmp[3]+"\t" + vectFastaHead.get(i)+"\n");
			
		}
		
		CommonFunction.writeContentToFile(this.fout, bufResult+"");
		
		
		}
	
	public static void main(String[] args) {
		
		PromoterID_FastaHeader obj = new PromoterID_FastaHeader();
//		obj.init(args[0], args[1], args[2]);
		
		obj.init(args[0], args[1], args[2]);
		
		obj.doProcessing();
		
	}
}
