package tcof.com.cbrc.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Random;
import java.util.Vector;
import java.util.regex.Pattern;

import org.apache.commons.math.special.Gamma;

//import tcof.com.cbrc.common.CommonFunction;
import tcof.com.cbrc.bean.BedFormat;
import tcof.com.cbrc.bean.FastaMult;
import tcof.com.cbrc.bean.TrxExonInfo;
import tcof.com.cbrc.constant.ConstantValue;

public class CommonFunction {

	public static Random myrand = new Random();
	
	public static NumberFormat formatterScientific = new DecimalFormat("0.#####E0");
	static Random generator = new Random( 19580427 );
	
	public static   boolean isWindows() {

		String os = System.getProperty("os.name").toLowerCase();
		// windows
		return (os.indexOf("win") >= 0);

	}

	public  static boolean isUnix() {

		String os = System.getProperty("os.name").toLowerCase();
		// linux or unix
		return (os.indexOf("nix") >= 0 || os.indexOf("nux") >= 0);

	}
	
	
	public static void findDuplicateTerms(String fName, String fnmOutDup, String fnmUniq)
	{
		Vector<String> allWords = CommonFunction.readlinesOfAfile(fName);
		LinkedHashMap<String, String> lhmUniq = new LinkedHashMap<String, String>();
		
		StringBuffer bufDup = new StringBuffer();
		StringBuffer bufUniq = new StringBuffer();
		String key;
		for(int i=0; i<allWords.size() ;i++)
		{
			key = allWords.get(i) ;
			if(lhmUniq.containsKey( key) ) {
				
				bufDup.append(key +"\n") ;
			}else
			{
				lhmUniq.put(key, key);
				bufUniq.append( key +"\n") ;
			}
		}
		
		CommonFunction.writeContentToFile(fnmOutDup, bufDup+"");
		CommonFunction.writeContentToFile(fnmUniq, bufUniq+"");
	}
	
	
	public static void readLastColumn(String fnmBedWith1column)
	{
		Vector<String > vectLines = CommonFunction.readlinesOfAfile(fnmBedWith1column);
		String curLine;
		String tmp[];
		int sum=0 , totNozZero=0,n;
		int totField;
		int i=0;
		for( i=0; i<vectLines.size();i++)
		{
			curLine = vectLines.get(i);
			tmp = ConstantValue.patWhiteSpace.split(curLine);
			totField = tmp.length;
			n = Integer.parseInt(tmp[totField - 1]);
			
			sum += n;
			if(n>0)
				totNozZero+=1;
		}
		
//		System.out.println("Tot non-zero entry: "+totNozZero + "\t sum:" + sum +  "\t avg:" + sum/i );
		System.out.println(totNozZero  );
		
	}
	
	
//	HG19_CHR20_43849009_43851009_+
	public static String fasta_HeaderWithoutAngle(String chrm, String start, String end, String strand)
	{
		String  s = null;
		s = "HG19"+"_" + chrm.toUpperCase() + "_"  + start  + "_"  + end + "_" + strand  ;
		return  s;
	}

	/*
	 *  Returens the header of fasta file
	 */
	public static Vector<String>  fasta_readFastaHeader(String fnmFasta)
	{
		Vector<String> header = null; 
		try {

			header = new Vector<String>();
			FileInputStream fstream = new FileInputStream(fnmFasta);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			while ((strLine = br.readLine()) != null) {
				if(strLine.length()<3)
					continue;
				if(strLine.startsWith(">"))
					header.add(strLine);
			}

			br.close();
			in.close();
			fstream.close();


		} catch (Exception e) {

			e.printStackTrace();
		}
		return header;
	}

	
	public static void fasta_doAllSetOperation_SequenceBased_MultiLines (String fnameA, String fnameB)
	{

		FastaMult fast1 = CommonFunction.fasta_readFasta_Multiplelines(fnameA);
		FastaMult fast2 = CommonFunction.fasta_readFasta_Multiplelines(fnameB);


		StringBuffer buf = new StringBuffer();
		StringBuffer tmp = new StringBuffer();



		Set setFirst = new LinkedHashSet();
		Set setSecond = new LinkedHashSet();

		int index;
		String header;

		try {



			for(int i=0; i<fast1.getHeader().size() ; i++)
			{
				setFirst.add(fast1.getSeq().get(i) );
			}
			buf.append( "A size:"+ setFirst.size() +"\n");



			for(int i=0;i<fast2.getSeq().size();i++)
			{
				setSecond.add(fast2.getSeq().get(i));
			}
			buf.append("B size:"+ setSecond.size() + "\n");




			Set intersection = new LinkedHashSet<String>(setSecond);
			intersection.retainAll(setFirst);


			buf.append("************ Common: " + intersection.size() + "*****************" + "\n") ;
			

			Set differenceNF = new LinkedHashSet(setFirst);
			differenceNF.removeAll(setSecond);
			buf.append( "*****************" + "A -B size:" + differenceNF.size() +  "*****************" +"\n" ) ; 
			



			Set differenceFN = new LinkedHashSet(setSecond);
			differenceFN.removeAll(setFirst);
			buf.append( "*****************" +" B -A size:" + differenceFN.size() +  "*****************" + "\n") ;
			


			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperationFasta.out"));

			bwr.write(buf+"");
			bwr.close();


		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void fasta_doAllSetOperation_headerBased_MultiLines (String fnameA, String fnameB)
	{

		FastaMult fast1 = CommonFunction.fasta_readFasta_Multiplelines(fnameA);
		FastaMult fast2 = CommonFunction.fasta_readFasta_Multiplelines(fnameB);


		StringBuffer buf = new StringBuffer();
		StringBuffer tmp = new StringBuffer();



		Set setFirst = new LinkedHashSet();
		Set setSecond = new LinkedHashSet();

		int index;
		String header;

		try {



			for(int i=0; i<fast1.getHeader().size() ; i++)
			{
				setFirst.add(fast1.getHeader().get(i) );
			}
			buf.append( "A size:"+ setFirst.size() +"\n");



			for(int i=0;i<fast2.getHeader().size();i++)
			{
				setSecond.add(fast2.getHeader().get(i));
			}
			buf.append("B size:"+ setSecond.size() + "\n");




			Set intersection = new LinkedHashSet<String>(setSecond);
			intersection.retainAll(setFirst);


			buf.append("************ Common: " + intersection.size() + "*****************" + "\n") ;
			Iterator itrCom = intersection.iterator();
			while( itrCom.hasNext())
			{
				header = (String)itrCom.next();
				buf.append(  header +"\n");
				index = fast1.getLhmHeader_VectIndex().get(header);
				buf.append(  fast1.getSeq().get(index) +"\n");
			}

			Set differenceNF = new LinkedHashSet(setFirst);
			differenceNF.removeAll(setSecond);
			buf.append( "*****************" + "A -B size:" + differenceNF.size() +  "*****************" +"\n" ) ; 
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				header = (String)itr.next();
				buf.append(  header +"\n");
				index = fast1.getLhmHeader_VectIndex().get(header);
				buf.append(  fast1.getSeq().get(index) +"\n");
			}



			Set differenceFN = new LinkedHashSet(setSecond);
			differenceFN.removeAll(setFirst);
			buf.append( "*****************" +" B -A size:" + differenceFN.size() +  "*****************" + "\n") ;
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				header = (String)itr2.next();
				buf.append(  header +"\n");
				index = fast2.getLhmHeader_VectIndex().get(header);
				buf.append(  fast2.getSeq().get(index) +"\n");
			}




			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperationFasta.out"));

			bwr.write(buf+"");
			bwr.close();


		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void fasta_doAllSetOperation_headerBased_MultiLines_DifferentMeaning	(String fnameA, String fnameB , String fnmOut)
	{

		FastaMult fast1 = CommonFunction.fasta_readFasta_Multiplelines_DifferentMeaning(fnameA);
		FastaMult fast2 = CommonFunction.fasta_readFasta_Multiplelines_DifferentMeaning(fnameB);


		StringBuffer buf = new StringBuffer();
		StringBuffer tmp = new StringBuffer();



		Set setFirst = new LinkedHashSet();
		Set setSecond = new LinkedHashSet();

		int index;
		String header;

		try {



			for(int i=0; i<fast1.getHeader().size() ; i++)
			{
				setFirst.add(fast1.getHeader().get(i) );
			}
			buf.append( "A size:"+ setFirst.size() +"\n");



			for(int i=0;i<fast2.getHeader().size();i++)
			{
				setSecond.add(fast2.getHeader().get(i));
			}
			buf.append("B size:"+ setSecond.size() + "\n");




			Set intersection = new LinkedHashSet<String>(setSecond);
			intersection.retainAll(setFirst);


			buf.append("************ Common: " + intersection.size() + "*****************" + "\n") ;
			Iterator itrCom = intersection.iterator();
			while( itrCom.hasNext())
			{
				header = (String)itrCom.next();
				buf.append(  header +"\n");
				index = fast1.getLhmHeader_VectIndex().get(header);
				buf.append(  fast1.getSeq().get(index) +"\n");
			}

			Set differenceNF = new LinkedHashSet(setFirst);
			differenceNF.removeAll(setSecond);
			buf.append( "*****************" + "A -B size:" + differenceNF.size() +  "*****************" +"\n" ) ; 
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				header = (String)itr.next();
				buf.append(  header +"\n");
				index = fast1.getLhmHeader_VectIndex().get(header);
				buf.append(  fast1.getSeq().get(index) +"\n");
			}



			Set differenceFN = new LinkedHashSet(setSecond);
			differenceFN.removeAll(setFirst);
			buf.append( "*****************" +" B -A size:" + differenceFN.size() +  "*****************" + "\n") ;
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				header = (String)itr2.next();
				buf.append(  header +"\n");
				index = fast2.getLhmHeader_VectIndex().get(header);
				buf.append(  fast2.getSeq().get(index) +"\n");
			}




			BufferedWriter bwr = new BufferedWriter(new FileWriter(fnmOut));

			bwr.write(buf+"");
			bwr.close();


		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 *   -------- Select a subset of fasta,  if Header matches ---------
	 *   
	 *  fnmFasta4Header -- list of header
	 *  fnmFasta - all fasta
	 *  fnmSelected - output of selected fasta subset
	 */
	public static void fasta_subsetSelect_ByMatchingHeader_MultiLines(String fnmFasta4Header, String fnmFasta, String fnmSelected)
	{
		Vector<String> vectHeader = fasta_readFastaHeader(fnmFasta4Header); 
		FastaMult multFastaMult = fasta_readFasta_Multiplelines(fnmFasta);

		StringBuffer buf = new StringBuffer();
		int index; 

		for(int i=0;i<vectHeader.size();i++)
		{
			if(multFastaMult.getLhmHeader_VectIndex().containsKey(vectHeader.get(i)))
			{
				index = multFastaMult.getLhmHeader_VectIndex().get(vectHeader.get(i));
				buf.append(multFastaMult.getHeader().get(index) + "\n" );
				buf.append(multFastaMult.getSeq().get(index) + "\n");
			}

		}

		try {
			BufferedWriter bwr = new BufferedWriter( new FileWriter(fnmSelected));
			bwr.write(buf+"");
			bwr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	/*
	 *   -------- Select a subset of fasta,  if Header matches ---------
	 *  
	 *  fnmFasta4Header -- list of header
	 *  fnmFasta - all fasta
	 *  fnmSelected - output of selected fasta subset
	 */
	public static void fasta_subsetSelect_ByMatchingHeader_MultiLines_DifferentMeaning (String fnmFasta4Header, String fnmFasta, String fnmSelected)
	{
		Vector<String> vectHeader = fasta_readFastaHeader(fnmFasta4Header); 
		FastaMult multFastaMult = fasta_readFasta_Multiplelines_DifferentMeaning(fnmFasta);

		StringBuffer buf = new StringBuffer();
		int index; 

		for(int i=0;i<vectHeader.size();i++)
		{
			if(multFastaMult.getLhmHeader_VectIndex().containsKey(vectHeader.get(i)))
			{
				index = multFastaMult.getLhmHeader_VectIndex().get(vectHeader.get(i));
				buf.append(multFastaMult.getHeader().get(index) + "\n" );
				buf.append(multFastaMult.getSeq().get(index) + "\n");
			}

		}

		try {
			BufferedWriter bwr = new BufferedWriter( new FileWriter(fnmSelected));
			bwr.write(buf+"");
			bwr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	public  static FastaMult fasta_readFasta_Multiplelines (String fnmFasta)
	{

		FastaMult obj = new FastaMult();
		try {

			Vector<String> header = null; 
			Vector<String> seq = null; 
			LinkedHashMap<String, Integer> lhmHead_Ind = null;

			StringBuffer tmp= new StringBuffer();;

			try {

				header = new Vector<String>();
				seq = new Vector<String>();
				lhmHead_Ind = new LinkedHashMap<String, Integer>();

				FileInputStream fstream = new FileInputStream(fnmFasta);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));

				String strLine;
				String beforeTrim;

				int index=0;

				while ((beforeTrim = br.readLine()) != null) {
					strLine = beforeTrim.trim();
					if(strLine.length() <=0)
						continue;

					if(strLine.startsWith(">")){
						header.add(strLine);

						if( !lhmHead_Ind.containsKey(strLine))
						{
							lhmHead_Ind.put(strLine, index);
						}



						index++;
						if( header.size() !=1) // for first case, do not append sequence
						{
							seq.add(tmp+"");
							tmp = new StringBuffer();

						}

					}else
					{
						tmp.append(strLine);
					}

				}
				seq.add(tmp+"");

				//				System.out.println("Total #seq in Multiple-lined fasta: " + seq.size() );

				br.close();
				in.close();
				fstream.close();


			} catch (Exception e) {

				e.printStackTrace();
			}




			obj.header = header;
			obj.seq = seq;
			obj.lhmHeader_VectIndex = lhmHead_Ind;

		} catch (Exception e) {
			e.printStackTrace();
		}



		return obj;

	}

	/*
	 *  Read a file like multiple fasta , but different lines means different meaning
	 */
	public  static FastaMult fasta_readFasta_Multiplelines_DifferentMeaning (String fnmFasta)
	{

		FastaMult obj = new FastaMult();
		try {

			Vector<String> header = null; 
			Vector<String> seq = null; 
			LinkedHashMap<String, Integer> lhmHead_Ind = null;

			StringBuffer tmpBuf= new StringBuffer();;

			try {

				header = new Vector<String>();
				seq = new Vector<String>();
				lhmHead_Ind = new LinkedHashMap<String, Integer>();

				FileInputStream fstream = new FileInputStream(fnmFasta);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));

				String strLine;
				String beforeTrim;

				int index=0;

				while ((beforeTrim = br.readLine()) != null) {
					strLine = beforeTrim.trim();
					if(strLine.length() <=0)
						continue;

					if(strLine.startsWith(">")){
						header.add(strLine);

						if( !lhmHead_Ind.containsKey(strLine))
						{
							lhmHead_Ind.put(strLine, index);
						}

						index++;
						if( header.size() !=1) // for first case, do not append sequence
						{
							seq.add(tmpBuf.toString().trim()+"");
							tmpBuf = new StringBuffer();

						}

					}else
					{
						tmpBuf.append(strLine+"\n");
					}

				}
				seq.add(tmpBuf.toString().trim()+"");

				//				System.out.println("Total #seq in Multiple-lined fasta: " + seq.size() );

				br.close();
				in.close();
				fstream.close();


			} catch (Exception e) {

				e.printStackTrace();
			}

			obj.header = header;
			obj.seq = seq;
			obj.lhmHeader_VectIndex = lhmHead_Ind;

		} catch (Exception e) {
			e.printStackTrace();
		}



		return obj;

	}


	

	/*
	 *  Returns unique HEADER entry of a fasta file
	 */
	public  static FastaMult fasta_read_Unique_Header_FastaMultiplelines (String fnmFasta)
	{

		FastaMult obj = new FastaMult();
		try {

			Vector<String> vectHeader = null; 
			Vector<String> vectSeq = null; 

			Vector<String> vectHeaderUniq = new Vector<String>(); 
			Vector<String> vectSeqUniq = new Vector<String>(); 


			/*
			 *  Key - Fasta Header
			 *  Value - 0-based index in vector
			 */
			LinkedHashMap<String, Integer> lhmHead_Ind = null;

			StringBuffer tmp= new StringBuffer();

			String header;

			try {

				vectHeader = new Vector<String>();
				vectSeq = new Vector<String>();
				lhmHead_Ind = new LinkedHashMap<String, Integer>();

				FileInputStream fstream = new FileInputStream(fnmFasta);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));

				String strLine;
				String beforeTrim;

				int index=0;

				while ((beforeTrim = br.readLine()) != null) {
					strLine = beforeTrim.trim();
					if(strLine.length() <=0)
						continue;

					if(strLine.startsWith(">")){

						header = strLine;

						//						if(lhmHead_Ind.containsKey(header))
						//							System.out.println("EXIST:" + header);
						if( ! lhmHead_Ind.containsKey(header))
						{
							lhmHead_Ind.put(header, index);
						}

						vectHeader.add(header);
						index++;
						if( vectHeader.size() !=1) // for first case, do not append sequence
						{
							vectSeq.add(tmp+"");
							tmp = new StringBuffer();

						}

					}else
					{
						tmp.append(strLine);
					}

				}
				vectSeq.add(tmp+"");

				//				System.out.println("Total #seq in Multiple-lined fasta: " + seq.size() );

				br.close();
				in.close();
				fstream.close();


			} catch (Exception e) {

				e.printStackTrace();
			}

			/*
			 *  	NOW CHECK THE UNIQUENESS
			 */

			int index ;
			Set set = lhmHead_Ind.entrySet();
			System.out.println("Total Unique header in fasta line:" + set.size() ) ;
			Iterator itr = set.iterator();
			while(itr.hasNext()){


				Map.Entry me = (Map.Entry) itr.next();
				String myHead = (String)me.getKey();
				index = (Integer) me.getValue();

				vectHeaderUniq.add(vectHeader.get(index));
				vectSeqUniq.add(vectSeq.get(index));

			}


			obj.header = vectHeaderUniq;
			obj.seq = vectSeqUniq;
			obj.lhmHeader_VectIndex = lhmHead_Ind;


		} catch (Exception e) {
			e.printStackTrace();
		}



		return obj;

	}


	/*
	 *  Returns unique SEQ entry of a fasta file
	 */
	public  static FastaMult fasta_read_Unique_Sequence_FastaMultiplelines (String fnmFasta)
	{

		FastaMult result=null;

		FastaMult multUniqHeader = fasta_read_Unique_Header_FastaMultiplelines(fnmFasta);

		LinkedHashMap<String, Integer> lhm_Seq_index = new LinkedHashMap<String, Integer>();

		Vector<String> head = new Vector<String>();
		Vector<String> seqUniq = new Vector<String>();
		LinkedHashMap<String, Integer> lhm_Header_index = new LinkedHashMap<String, Integer>();

		String stringOfInterest=null;
		int totUniqSeq=0;

		for(int i=0; i<  multUniqHeader.getSeq().size() ;i++)
		{
			stringOfInterest = multUniqHeader.getSeq().get(i);
			
			if(  ! lhm_Seq_index.containsKey(stringOfInterest  ) )
			{
				lhm_Seq_index.put(multUniqHeader.getSeq().get(i), i) ;
				seqUniq.add(stringOfInterest);
				head.add(multUniqHeader.getHeader().get(i));
				lhm_Header_index.put(multUniqHeader.getHeader().get(i), i);

				totUniqSeq++;
			}
		}

		System.out.println("Total Uniq whole Seq : " + totUniqSeq);
		
		FastaMult uniqSeqFastaMult=  new FastaMult();
		uniqSeqFastaMult.header = head;
		uniqSeqFastaMult.seq = seqUniq;
		uniqSeqFastaMult.lhmHeader_VectIndex = lhm_Header_index;

		return uniqSeqFastaMult;

	}

	/*
	 *  Returns unique SEQ entry of a fasta file
	 */
	public  static FastaMult fasta_read_Unique_Subregion_Sequence_FastaMultiplelines (String fnmFasta, int start_0based, int end_0based)
	{

		FastaMult result=null;

		FastaMult multUniqHeader = fasta_read_Unique_Header_FastaMultiplelines(fnmFasta);

		LinkedHashMap<String, Integer> lhm_Seq_index = new LinkedHashMap<String, Integer>();

		Vector<String> head = new Vector<String>();
		Vector<String> seqUniq = new Vector<String>();
		LinkedHashMap<String, Integer> lhm_Header_index = new LinkedHashMap<String, Integer>();

		String stringOfInterest=null;
		int totUniqSeq=0;

		for(int i=0; i<  multUniqHeader.getSeq().size() ;i++)
		{
			stringOfInterest = multUniqHeader.getSeq().get(i).substring(start_0based, end_0based+1);
			
			if(  ! lhm_Seq_index.containsKey( stringOfInterest  ) )
			{
				lhm_Seq_index.put( stringOfInterest, i) ;
				seqUniq.add( stringOfInterest  ); 
				head.add(multUniqHeader.getHeader().get(i));
				lhm_Header_index.put(multUniqHeader.getHeader().get(i), i);
				
				totUniqSeq++;

			}
		}

		System.out.println("Total Uniq sub-region of Seq : " + totUniqSeq);
		
		FastaMult uniqSeqFastaMult=  new FastaMult();
		uniqSeqFastaMult.header = head;
		uniqSeqFastaMult.seq = seqUniq;
		uniqSeqFastaMult.lhmHeader_VectIndex = lhm_Header_index;

		return uniqSeqFastaMult;

	}
	

	/*
	 *  Conver fasta header from Text to SequenceNumber
	 */
	public  static FastaMult fasta_Header_To_Numerical (String fnmFasta)
	{

		FastaMult obj = new FastaMult();
		try {

			Vector<String> header = null; 
			Vector<String> seq = null; 
			LinkedHashMap<String, Integer> lhmHead_Ind = null;

			StringBuffer tmp= new StringBuffer();;

			try {

				header = new Vector<String>();
				seq = new Vector<String>();
				lhmHead_Ind = new LinkedHashMap<String, Integer>();

				FileInputStream fstream = new FileInputStream(fnmFasta);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));

				String strLine;
				String beforeTrim;

				int index=0;

				while ((beforeTrim = br.readLine()) != null) {
					strLine = beforeTrim.trim();
					if(strLine.length() <=0)
						continue;

					if(strLine.startsWith(">")){
						header.add(">"+index+"");

						if( !lhmHead_Ind.containsKey(">"+index+""))
						{
							lhmHead_Ind.put(">"+index+"", index);
						}

						index++;
						if( header.size() !=1) // for first case, do not append sequence
						{
							seq.add(tmp+"");
							tmp = new StringBuffer();

						}

					}else
					{
						tmp.append(strLine);
					}

				}
				seq.add(tmp+"");

				//				System.out.println("Total #seq in Multiple-lined fasta: " + seq.size() );

				br.close();
				in.close();
				fstream.close();


			} catch (Exception e) {

				e.printStackTrace();
			}




			obj.header = header;
			obj.seq = seq;
			obj.lhmHeader_VectIndex = lhmHead_Ind;

		} catch (Exception e) {
			e.printStackTrace();
		}



		return obj;

	}

	/*
	 *  Select 0-BASED start and end sub-region of each sequence of fasta file
	 */
	public static FastaMult fasta_SubRegion_FromAll_1 (String fnmFasta, int start_0based, int end_0based)
	{
		FastaMult mult = CommonFunction.fasta_readFasta_Multiplelines(fnmFasta);

		int totSeq = mult.getSeq().size();
		String curS;
		for(int i=0;i< totSeq;i++)
		{
			curS = mult.getSeq().get(i);
			mult.getSeq().set(i, curS.substring(start_0based, end_0based+1 )) ;
		}

		return mult;
	}





	public  static void fasta_mult_To_singleFasta (String fnmFasta , String fnmOut)
	{

		BufferedWriter bwr;
		FastaMult obj = fasta_readFasta_Multiplelines(fnmFasta);

		StringBuffer buf = new StringBuffer();

		for(int i=0 ; i<obj.getHeader().size(); i++)
		{
			buf.append( obj.getHeader().get(i)+"\n" );
			buf.append( obj.getSeq().get(i) + "\n");
		}

		try {

			bwr = new BufferedWriter(new FileWriter( fnmOut));
			bwr.write(buf+"");
			bwr.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	public  static void fasta_mult_To_singleFasta_MulticellularDB (String fnmFasta , String fnmOut)
	{

		BufferedWriter bwr;
		FastaMult obj = fasta_readFasta_Multiplelines(fnmFasta);

		StringBuffer buf = new StringBuffer();
		String tmp;
		int len;
		for(int i=0 ; i<obj.getHeader().size(); i++)
		{
			buf.append( obj.getHeader().get(i)+"\n" );
			tmp = obj.getSeq().get(i) ;
			len = tmp.length();

			if(tmp.charAt(len-1) =='*')
				buf.append( tmp.substring(0, len-1)+ "\n");
		}

		try {

			bwr = new BufferedWriter(new FileWriter( fnmOut));
			bwr.write(buf+"");
			bwr.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	/*
	 *  Create 1 file for each multi-line fasta of a file
	 */
	public  static void fasta_splitFasta_Numbered (String fnmFasta , String outDir)
	{

		BufferedWriter bwr;
		FastaMult obj = fasta_readFasta_Multiplelines(fnmFasta);

		StringBuffer buf = new StringBuffer();

		for(int i=0 ; i<obj.getHeader().size(); i++)
		{
			buf = new StringBuffer();

			buf.append( obj.getHeader().get(i)+"\n" );
			buf.append( obj.getSeq().get(i));

			try {

				bwr = new BufferedWriter(new FileWriter(outDir + "/"+ (i+1) + ".fa" ));
				bwr.write(buf+"");
				bwr.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}


	


	

	
	
	public static void doAllSetOperation(String fnameA, String fnameB)
	{
		StringBuffer buf = new StringBuffer();
		StringBuffer tmp = new StringBuffer();
		
		
		
		Set setNurse = new LinkedHashSet();
		Set setForager = new LinkedHashSet();
	
		try {

			FileInputStream fstream = new FileInputStream(fnameA);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			String beforeTrim;
			while(  (beforeTrim = br.readLine()) !=null)
			{
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				setNurse.add(  strLine );
			}
			br.close(); in.close(); fstream.close();
			buf.append( "A size:"+ setNurse.size() +"\n");
			
			
			FileInputStream fstream2 = new FileInputStream(fnameB);
			DataInputStream in2 = new DataInputStream(fstream2);
			BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
			
			while(  (beforeTrim = br2.readLine()) !=null)
			{
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				setForager.add(  strLine );
			}
			buf.append("B size:"+ setForager.size() + "\n");
			
			
			br2.close(); in2.close(); fstream2.close();
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);

			
			buf.append("************ Common: " + intersection.size() + "*****************" + "\n") ;
			Iterator itrCom = intersection.iterator();
			while( itrCom.hasNext())
			{
				buf.append(  itrCom.next() +"\n");
			}
			
			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append( "*****************" + "A -B size:" + differenceNF.size() +  "*****************" +"\n" ) ; 
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append( "*****************" +" B -A size:" + differenceFN.size() +  "*****************" + "\n") ;
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				buf.append(  itr2.next() +"\n");
			}
			
			
			
			
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperation.out"));
			
			bwr.write(buf+"");
			bwr.close();
		
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void doAllSetOperation(Vector<String> vA, Vector<String> vB)
	{
		Set setNurse  = new LinkedHashSet<String>();
		Set setForager  = new LinkedHashSet<String>();
		
		for(int i=0;i<vA.size();i++)
		{
			setNurse.add(vA.get(i) );
		}
		
		for(int i=0;i<vB.size();i++)
		{
			setForager.add(vB.get(i) );
		}
		
	
		try {
			StringBuffer buf = new StringBuffer();
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperation.out"));
			
			buf.append("**********  A size :"+ setNurse.size() + "******************* " +"\n");
			buf.append("********** B size :"+ setForager.size() + "******************* " +"\n");
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);
			buf.append("**********  Common:"+ intersection.size() + "******************* " +"\n");
			Iterator itrCom = intersection.iterator();
			while( itrCom.hasNext())
			{
				buf.append(  itrCom.next() +"\n");
			}

			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append("**********  A-B:"+ differenceNF.size() + "******************* " +"\n");
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append("**********  B-A:"+ differenceFN.size() + "******************* " +"\n");
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				buf.append(  itr2.next() +"\n");
			}

			bwr.write(buf+"");
			bwr.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public static void doAllSetOperation(Set A, Set B)
	{
		
		Set setNurse = A;
		Set setForager = B;
	
		try {
			StringBuffer buf = new StringBuffer();
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperation.out"));
			
			buf.append("**********  A size :"+ setNurse.size() + "******************* " +"\n");
			buf.append("********** B size :"+ setForager.size() + "******************* " +"\n");
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);
			buf.append("**********  Common:"+ intersection.size() + "******************* " +"\n");
			

			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append("**********  A-B:"+ differenceNF.size() + "******************* " +"\n");
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append("**********  B-A:"+ differenceFN.size() + "******************* " +"\n");
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				buf.append(  itr2.next() +"\n");
			}

			bwr.write(buf+"");
			bwr.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void doAllSetOperationStat(Set A, Set B)
	{
		
		Set setNurse = A;
		Set setForager = B;
	
		try {
			StringBuffer buf = new StringBuffer();
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperationStat.out"));
			
			buf.append("**********  A size :"+ setNurse.size() + "******************* " +"\n");
			buf.append("********** B size :"+ setForager.size() + "******************* " +"\n");
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);
			buf.append("**********  Common:"+ intersection.size() + "******************* " +"\n");
			

			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append("**********  A-B:"+ differenceNF.size() + "******************* " +"\n");
//			Iterator itr = differenceNF.iterator();
//			while( itr.hasNext())
//			{
//				buf.append(  itr.next() +"\n");
//			}
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append("**********  B-A:"+ differenceFN.size() + "******************* " +"\n");
//			Iterator itr2 = differenceFN.iterator();
//			while( itr2.hasNext())
//			{
//				buf.append(  itr2.next() +"\n");
//			}

			bwr.write(buf+"");
			bwr.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void doAllSetOperation(String fnameA, int zeroBasedIndexA,  String fnameB , int zeroBasedIndexB )
	{
		
		Set setNurse = new LinkedHashSet();
		Set setForager = new LinkedHashSet();
		String tmp[];
		StringBuffer buf = new StringBuffer();
		try {

			FileInputStream fstream = new FileInputStream(fnameA);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperation.out"));
			
			String strLine;
			String beforeTrim;
			while(  (beforeTrim = br.readLine()) !=null)
			{
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				tmp = ConstantValue.patWhiteSpace.split(strLine);
				setNurse.add(  tmp[zeroBasedIndexA] );
			}
			br.close(); in.close(); fstream.close();
			buf.append("**********  A size :"+ setNurse.size() + "******************* " +"\n");
			
			
			FileInputStream fstream2 = new FileInputStream(fnameB);
			DataInputStream in2 = new DataInputStream(fstream2);
			BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
			while(  (beforeTrim = br2.readLine()) !=null)
			{
				strLine = beforeTrim.trim();
				if(strLine.length() <= 0)
					continue;
				tmp = ConstantValue.patWhiteSpace.split(strLine);
				setForager.add(  tmp[zeroBasedIndexB] );
			}
			buf.append("**********  B size :"+ setForager.size() + "******************* "  +"\n" );
			br2.close(); in2.close(); fstream2.close();
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);
			buf.append("*********** Common: " + intersection.size() + "****************"  +"\n" ) ;
			Iterator itr = intersection.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append(  "****************" + "diff A-B:" + differenceNF.size() + "****************"  +"\n") ;
			itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append(  "****************" + "diff B-A:" + differenceFN.size() + "****************"  +"\n") ;
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				buf.append(  itr2.next() +"\n");
			}
			
			bwr.write(buf + "");
			bwr.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static double  callFisherExactTest(int a, int b, int c, int d)
	{

		int hitA = a;
		int hitAB = a+ b;
		int totA = a+c;
		int totAB = a+b+c+d;
		return calcRightsidePValue(hitA, hitAB, totA, totAB);
	}
	
	/*
	 *                 CLASSA    CLASSB
	 *                        -----------------
	 *  PRESENT    |    k    |        |    TOTALpresent=n
	 *  ABSENT      |          |        |    TOTALabsent
	 *                         -------------------------------
	 *  TOTALclassA|        |        | TOTALclass A + B
	 *                 K                                    N
	 */

	/*
	 *  k - #PRESENT in CLASSA
	 *  n - #PRESENT in CLASSA + CLASSB
	 *
	 *  K - #TOTAL sample in CLASSA
	 *  N - #TOTAL sample in CLASSA + CLASSB
	 */
	public static double calcRightsidePValue( int hitA,int hitAB,int totA,int totAB )
	{
	        double pv,t1,x;

	/*
	        k      n-k         |  n
	        K-k    (N-K)-(n-k) |  N-n
	        -------------------------
	        K      N-K         |  N


	        This calculates the Right Hand Side PValue.
	        (LHS would be k=0,n.)
	*/
	        t1= Gamma.logGamma(((double) totA+1))+
	        		Gamma.logGamma(((double) totAB-totA+1))-
	        		Gamma.logGamma(((double) totAB+1))+
	        		Gamma.logGamma(((double) hitAB+1))+
	        		Gamma.logGamma(((double) totAB-hitAB+1));
	        
	        for (pv=-1e100; hitA<=hitAB && hitA<=totA && (hitAB-hitA)<=(totAB-totA);   hitA++) {
	                x=t1-Gamma.logGamma(((double) hitA+1))-Gamma.logGamma(((double) totA-hitA+1))-Gamma.logGamma(((double) hitAB-hitA+1))-+Gamma.logGamma(((double) totAB-totA-hitAB+hitA+1));
	                
	                pv=( pv>=x  ? pv+  Math.log(1.0+Math.exp(x-pv))  :  x+ Math.log(1.0+ Math.exp(pv-x)));
	        }

	        // Bonferroni correction (pval * nSEQF)
	        //rankDB[id].pvalue=((float) rankDB[id].nSEQF)*exp(pv);
	        //rankDB[id].pvalue=exp(pv);
	        return( Math.exp(pv));
	}
	
	
	public static boolean isOverlap( int promStart, int promEnd , int snpStart, int snpEnd )
	{

		int overlapStart = promStart > snpStart ? promStart : snpStart ; // take max
		int overlapEnd   = promEnd   < snpEnd   ? promEnd   : snpEnd   ; // take min
		int len = overlapEnd - overlapStart + 1;

		int overlapStartIndex = overlapStart - promStart   ;
		int overlapEndIndex   =  overlapStartIndex + len -1;
		
		if(overlapEndIndex >= overlapStartIndex)
			return true;
		else
			return false;
	}
	
	public static int getGenomicDist(int st1, int end1, int st2, int end2)
	{
		int minDist = Integer.MAX_VALUE;
		
		int a = Math.abs(st1 - st2);
		int b = Math.abs(st1 - end2);
		int c = Math.abs(end1 - st2);
		int d = Math.abs(end1 - end2);
		
		
		minDist = Math.min(  Math.min(a, b) , Math.min(c, d) );
		
		return minDist;
	}
	
	
	public static double distFromPoint( double refX, double refY , double poiX, double poiY)
	{
		
		return  Math.sqrt(   Math.pow((refX-poiX)  , 2) +  Math.pow(   (refY- poiY), 2) ) ;
		
	}
	
	public static int nucleotideToindex(char c) {
        switch (c) {

            case 'A':
            case 'a':
                	
                return 0;
            case 'C':
            case 'c':
                
                return 1;
            case 'G':
            case 'g':
                
                return 2;
            case 'T':
            case 't':
                
                return 3;
            default:
                double zeroToOne = myrand.nextDouble();
                if (zeroToOne >= 0 && zeroToOne <= .25) {
                    return 0;
                } else if (zeroToOne > .25 && zeroToOne <= .5) {
                    return 1;
                } else if (zeroToOne > .5 && zeroToOne <= .75) {
                    return 2;
                } else if (zeroToOne > .75 && zeroToOne <= 1.0) {
                    return 3;
                }
        }

        return 0;
	}
	
//	HG19_CHR20_43849009_43851009_+
	public static String fastaHeaderWithoutAngle(String chrm, String start, String end, String strand)
	{
		String  s = null;
		s = "HG19"+"_" + chrm.toUpperCase() + "_"  + start  + "_"  + end + "_" + strand  ;
		return  s;
	}
	
	
	public static String hocomocoHuman(String input)
	{
		int pos = input.indexOf('_');
		return input.substring(0, pos)+"_HUMAN";
	}
	
	
	/*
	 *  return index in [0 , size)
	 */
	public static int genRandomInZeroBasedRange( int size)
	{
		
		int r = generator.nextInt( size);
		return r;
	}
	
	
	public static String  formGeneID( String chrom, String start, String strand)
	{
		return  chrom+start+strand;
	}
	
	
	public  static Vector<String> readlinesOfAfile (String fnm)
	{

		Vector<String> seq = new Vector<String>();
		try {
			FileInputStream fstream = new FileInputStream(fnm);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			String beforeTrim;

			while ((beforeTrim = br.readLine()) != null) {
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				seq.add(strLine);
			}
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return seq;
	}
	
	
	public  static String readlinesOfAfileAsBuffer (String fnm)
	{

		StringBuffer seqBuf = new StringBuffer();
		try {
			FileInputStream fstream = new FileInputStream(fnm);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			String beforeTrim;

			while ((beforeTrim = br.readLine()) != null) {
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				seqBuf.append(strLine+"\n");
			}
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return seqBuf+"";
	}
	
	
	public  static Set<String> readlinesOfAfileInSet (String fnm)
	{

		Set<String> setSeq = new LinkedHashSet();
		try {
			FileInputStream fstream = new FileInputStream(fnm);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			String beforeTrim;

			while ((beforeTrim = br.readLine()) != null) {
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				setSeq.add(strLine);
			}
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return setSeq;
	}
	
	/*
	 *  Write the string into the file
	 */
	public static void writeContentToFile (String fnm, String content)
	{
		StringBuffer buf = new StringBuffer();
		try {
			BufferedWriter bwr = new BufferedWriter(new FileWriter(fnm));
			bwr.write(content+"");
			bwr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static Vector<BedFormat> readBedfile(String fnmBed)
	{
		Vector<BedFormat> vec = new Vector<BedFormat>();
		try {
			FileInputStream fstream = new FileInputStream(fnmBed);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String befTrim;
			String strLine;
			String tmp[];
			BedFormat bedForm;
			while ((befTrim = br.readLine()) != null) {
				strLine = befTrim.trim();
				
				tmp = ConstantValue.patWhiteSpace.split(strLine);
				bedForm = new BedFormat(tmp[0], Integer.parseInt(tmp[1]) , Integer.parseInt(  tmp[2] ) , tmp[3], tmp[4], tmp[5].charAt(0)  );
				vec.add(bedForm);
				
			}

			System.out.println("Total line in bed file:"+vec.size());
			
			br.close();
			in.close();
			fstream.close();

			
		} catch (Exception e) {

			e.printStackTrace();
		}
		
		return vec;
	}
	
	
	public static Vector<TrxExonInfo> readBedfileInDetails(String fnmBed)
	{
		String tmp[];
		Pattern p = Pattern.compile("[\\t]+");
		Vector<String> vectBedStr = CommonFunction.readlinesOfAfile(fnmBed);
		StringBuffer buf = new StringBuffer();
		Vector<TrxExonInfo> vectTrx = new Vector<TrxExonInfo>();
		for(int i=0;i<vectBedStr.size();i++)
		{
			tmp = p.split(vectBedStr.get(i), 12);
			TrxExonInfo trx = new TrxExonInfo(tmp[0], tmp[1], tmp[2], tmp[3], tmp[4], tmp[5], tmp[6], tmp[7], tmp[8], tmp[9], tmp[10], tmp[11]) ;
			vectTrx.add(trx);			
		}
		
		return vectTrx;
		
	}
	
	
	
	public static Vector<String>  readFastaHeader(String fnmFasta)
	{
		Vector<String> header = null; 
		try {

			header = new Vector<String>();
			FileInputStream fstream = new FileInputStream(fnmFasta);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			while ((strLine = br.readLine()) != null) {
				if(strLine.length()<3)
					continue;
				if(strLine.startsWith(">"))
					header.add(strLine);
			}

			br.close();
			in.close();
			fstream.close();

			
		} catch (Exception e) {

			e.printStackTrace();
		}
		return header;
	}
	
	
	
	public static boolean isEmptyFile(String fNm)
	{
		
		File f = new File(fNm);
		
		if(f.exists()){
			 
			double bytes = f.length();
			if(bytes>0)
				return true;
			else
				return false;
		}else{
			 return false;
		}

	}
	
	


	public static void readColumnCSV(String fnmBedWith1column, int index0based, String fnmOut)
	{
		Vector<String > vectLines = CommonFunction.readlinesOfAfile(fnmBedWith1column);
		String curLine;
		String tmp[];
		int sum=0 , totNozZero=0,n;
		int totField;
		int i=0;
		
		LinkedHashSet setColumn = new LinkedHashSet();
		
		
		for( i=0; i<vectLines.size();i++)
		{
			curLine = vectLines.get(i);
			tmp = ConstantValue.patWhiteSpace.split(curLine);
			totField = tmp.length;

			tmp = ConstantValue.patSemiColon_Comma.split(tmp[index0based]);
			
			for(int k=0; k<tmp.length;k++)
			{
				setColumn.add(tmp[k]);
			}
			
			
		}
		
		System.out.println("Tot  entry before removing none: "+ setColumn.size() );
		if(setColumn.contains("None"))
		{
			setColumn.remove("None");
		}

		System.out.println("Tot  entry after removing none: "+ setColumn.size() );

		
		StringBuffer buf = new StringBuffer();
		Iterator itr= setColumn.iterator();
		while(itr.hasNext())
		{
			buf.append(itr.next()+"\n");
		}
		
		writeContentToFile(fnmOut, buf+"");
		
		
	}
	
	
	
	public static void main(String[] args) {
		

		readColumnCSV("TF_Tcof.Name.txt.highconf", 1, "test.highconf");

//		doAllSetOperation("allID_IFNg.txt", 0,  "allID_IL413.txt" , 0 ) ;
		
//		 doAllSetOperation("allID_500_IFNg.txt", 0,  "allID_IFNg.txt" , 0 ) ;
//		doAllSetOperation("allID_500_IL413.txt", 0,  "allID_IL413.txt" , 0 ) ;
		
//		doAllSetOperation("FANTOMlncRNA.id.txt", 0,  "GencodeV2lncRNA.id.txt" , 0 ) ;
		
//		for(int i=0 ; i<10; i++)
//			System.out.println( genRandomInZeroBasedRange( 33 ) );
		
		// CPS
//		doAllSetOperation("significantRankedTFBSfromNC.motif.name", 0 , "final_encode.name", 0);
		
		// REFPS
//		doAllSetOperation("motifSelectedREFPS.name", 0 , "final_encode.name", 0);
//		doAllSetOperation("motifSelectedCPS.name", 0 , "final_encode.name", 0);
		
		
		// Suzuki VS M1, M2
//		doAllSetOperation("suzuki_lncRNAID_1TPM.txt", "tanvir_lncRNAID_1TMP.txt"); 
//		doAllSetOperation("suzuki_lncRNAID.txt", "m1_trxID.txt"); 
//		doAllSetOperation("suzuki_lncRNAID.txt", "m2_trxID.txt"); 
		
		
//		doAllSetOperation("mouse_macrophage_TB_infection_IL4-IL13.counts.csv.header", "mouse_macrophage_TB_infection_non-stimulated.counts.csv.header"); 
		
//		doAllSetOperation("mouse_macrophage_TB_infection_IL4-IL13.counts.csv.header", "mouse_macrophage_TB_infection_IL13.counts.csv.header");
		
//		doAllSetOperation("NFvsIFNG.DEG.4.24.DESEQ.sigGene", 0,  "NFvsIL413.DEG.4.24.DESEQ.sigGene" , 0 ) ;
		
//		doAllSetOperation("classic.cloverid", 0,  "alternative.cloverid" , 0 ) ;
		
		//////////  COMPARE WITH PREV LIST
//		Set<String> prev = readlinesOfAfileInSet ("./noncodingPrev.fasta"); // ("./allGene1.fasta");
//		Set<String> now = readlinesOfAfileInSet("./noncodingNow.fasta");//("./allGene2.fasta");
		
//		doAllSetOperationStat(prev, now);
//		doAllSetOperation(prev, now);
		
//		doAllSetOperation("CPSb", "prevCPSb"); 
//		doAllSetOperation("CPSd", "prevCPSd");
		
//		doAllSetOperation("tmp1.txt", "tmp2.txt"); 
//		doAllSetOperation("REFPSd", "prevREFPSd");
		
//		findDuplicateTerms("./tmp1.txt", "./dup.txt", "./uniq.txt");
		
//		
//		readLastColumn("coding.withrpt.bed.tmp.refseqcoding2014.CDS.bed.overlap");
//		readLastColumn("noncoding.withrpt.bed.tmp.refseqcoding2014.CDS.bed.overlap");

//		doAllSetOperation("noncoding.withrpt.bed.tmp.CGIoverlap.nooverlap.prom.bedtools", "CGIoverlap.nooverlap.prom");
		
//		doAllSetOperation("lncrna_CPS.txt", 0, "lncrna_CPS_afterCDS.txt", 0);
		
//		fasta_doAllSetOperation_SequenceBased_MultiLines("Galaxy12-[FASTA_Width_on_data_11].fasta", "allGene.fasta");
//		
		
//		readLastColumn("noncoding.withrpt.bed.Up.count");
//		readLastColumn("noncoding.withrpt.bed.Down.count");
//		readLastColumn("noncoding.withrpt.bed.count");
//		readLastColumn("/home/alamt/CNC/FANTOManalysis/noncoding.withrpt.bed.wholebody.bed.prom.count");
		
		
//		readLastColumn("coding.withrpt.bed.Up.count");
//		readLastColumn("coding.withrpt.bed.Down.count");
//		readLastColumn("coding.withrpt.bed.count");
//		readLastColumn("/home/alamt/CNC/FANTOManalysis//coding.withrpt.bed.wholebody.bed.prom.count");
//		
		
//		readLastColumn("noncoding.withrpt.bed.bp");
		
		
	}
	
}
