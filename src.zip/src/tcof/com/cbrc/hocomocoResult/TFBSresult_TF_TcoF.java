package tcof.com.cbrc.hocomocoResult;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import tcof.com.cbrc.common.CommonFunction;
import tcof.com.cbrc.constant.ConstantValue;

public class TFBSresult_TF_TcoF {

	
	String fnmHocomoceResult;
	String fnmTcofDB_Name;
	
	
	String fnmOut;
	
	/*
	 *  DATA STRUCTURE
	 */
	// KEY-TFname ; VAL-TFname;
	LinkedHashMap< String, String> lhm_hocomResult = new LinkedHashMap<String, String>();
	// KEY-TFname ; VAL-TcoFname;
	LinkedHashMap< String, String> lhm_TcoFDBnames = new LinkedHashMap<String, String>();
	
	
	
	void init(String hocomocoRes, String fnm_TF_TcoF_name, String out)
	{
		this.fnmHocomoceResult = hocomocoRes;
		this.fnmTcofDB_Name = fnm_TF_TcoF_name;
		this.fnmOut = out;
	}
	
	void loadHOCOMOCOresult()
	{
		Vector<String> vectResHocomoco = CommonFunction.readlinesOfAfile(this.fnmHocomoceResult);
		String tmp[];
		
		for(int i=0;i<vectResHocomoco.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectResHocomoco.get(i));
			lhm_hocomResult.put(tmp[0], tmp[0]);
		}
		System.out.println("Total TFBS overrepresented:" + lhm_hocomResult.size());
		
	}
	
	void loadAllNameFromTcoFDB()
	{
	
		Vector<String> vectAcc_Name = CommonFunction.readlinesOfAfile(this.fnmTcofDB_Name);
		String tmp[];
		
		for(int i=0;i<vectAcc_Name.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectAcc_Name.get(i));
			lhm_TcoFDBnames.put(tmp[0], tmp[1]);
		}
		System.out.println("Total TF_TcoF found:" + lhm_TcoFDBnames.size());
	}
	
	
	
	void writeOuput()
	{
		
		
		StringBuffer buf = new StringBuffer();
		
        Set set = lhm_hocomResult.entrySet();
        System.out.println("Total Unique entry:" + set.size() ) ;
        Iterator itr = set.iterator();
        while(itr.hasNext()){


            Map.Entry me = (Map.Entry) itr.next();
            String TFname = (String)me.getKey();
            String tcofList = (String) lhm_TcoFDBnames.get(TFname);
            
            buf.append(TFname+ "\t" + tcofList +"\n");
           
        }
        
        
        
        
        CommonFunction.writeContentToFile(this.fnmOut, buf+"");
		
	}
	
	void doProcessing()
	{
		loadHOCOMOCOresult();
		loadAllNameFromTcoFDB();
		
		
		writeOuput();
		
	}
	
	public static void main(String[] args) {
		
		TFBSresult_TF_TcoF obj = new TFBSresult_TF_TcoF();
		obj.init(args[0], args[1], args[2]);
		
		obj.doProcessing();
	}
}
